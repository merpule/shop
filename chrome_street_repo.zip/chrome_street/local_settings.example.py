# Скопируй в local_settings.py и впиши свои значения. Этот файл НЕ попадает в GitHub (.gitignore).
BOT_TOKEN = "PUT_BOT_TOKEN_HERE"
# Любую настройку из начала bot.py можно переопределить здесь, например:
# ADMIN_IDS = [123456789]
# MANAGER_USERNAME = "your_username"
