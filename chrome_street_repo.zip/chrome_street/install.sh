#!/usr/bin/env bash
# Установка бота на сервер (Ubuntu/Debian). Запуск от root:
#   bash install.sh                 - только бот (каталог в чате)
#   bash install.sh твой-домен.com  - бот + Mini App по HTTPS (домен должен указывать на IP сервера)
set -euo pipefail
DOMAIN="${1:-}"
APP=/opt/chrome_street
[ "$(id -u)" = 0 ] || { echo "Запусти от root"; exit 1; }
cd "$(dirname "$0")"
export DEBIAN_FRONTEND=noninteractive

apt-get update -y
apt-get install -y python3 python3-venv python3-pip curl unzip

id chromebot >/dev/null 2>&1 || useradd -r -m -d "$APP" -s /usr/sbin/nologin chromebot
mkdir -p "$APP"
cp bot.py index.html requirements.txt "$APP/"
[ -f shop.db ] && cp shop.db "$APP/" || true
[ -d photos ] && cp -r photos "$APP/" || true

python3 -m venv "$APP/venv"
"$APP/venv/bin/pip" install --upgrade pip
"$APP/venv/bin/pip" install -U -r "$APP/requirements.txt"


# секреты: если рядом лежит local_settings.py, он копируется на сервер
touch "$APP/local_settings.py"
[ -f local_settings.py ] && cp local_settings.py "$APP/local_settings.py"
# адрес Mini App (старая временная ссылка из bot.py отключается)
sed -i '/^WEBAPP_URL/d' "$APP/local_settings.py"
if [ -n "$DOMAIN" ]; then
  echo "WEBAPP_URL = \"https://$DOMAIN\"" >> "$APP/local_settings.py"
else
  echo 'WEBAPP_URL = ""' >> "$APP/local_settings.py"
fi
chown -R chromebot:chromebot "$APP"
chmod 600 "$APP/local_settings.py"

cp chrome-street.service /etc/systemd/system/chrome-street.service
systemctl daemon-reload
systemctl enable chrome-street
systemctl restart chrome-street

if [ -n "$DOMAIN" ]; then
  apt-get install -y debian-keyring debian-archive-keyring apt-transport-https gnupg || apt-get install -y gnupg
  curl -1sLf 'https://dl.cloudsmith.io/public/caddy/stable/gpg.key' | gpg --dearmor --yes -o /usr/share/keyrings/caddy-stable-archive-keyring.gpg
  curl -1sLf 'https://dl.cloudsmith.io/public/caddy/stable/debian.deb.txt' > /etc/apt/sources.list.d/caddy-stable.list
  apt-get update -y
  apt-get install -y caddy
  printf '%s {\n    reverse_proxy 127.0.0.1:8080\n}\n' "$DOMAIN" > /etc/caddy/Caddyfile
  systemctl restart caddy
fi

sleep 3
systemctl --no-pager --lines=15 status chrome-street || true
echo
echo "Готово. Логи бота:  journalctl -u chrome-street -f"
