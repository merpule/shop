"""
Бот-магазин ресейла вещей: каталог в чате + Mini App, оплата TON / USDT (CryptoBot) / СБП / карта,
после оплаты ссылка на менеджера. aiogram 3 + SQLite.
Запуск:  pip install -U aiogram aiohttp   ->   python bot.py
"""
import asyncio
import html
import logging
import os
import json
import sqlite3
import time
from pathlib import Path
from urllib.parse import quote

import aiohttp
from aiohttp import web
from aiogram import Bot, Dispatcher, F
from aiogram.client.default import DefaultBotProperties
from aiogram.enums import ParseMode
from aiogram.filters import Command, CommandObject, CommandStart, StateFilter
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.fsm.storage.memory import MemoryStorage
from aiogram.types import (BotCommand, CallbackQuery, InlineKeyboardButton, InputMediaPhoto,
                           MenuButtonWebApp, Message, WebAppInfo)
from aiogram.utils.keyboard import InlineKeyboardBuilder

# ============================ НАСТРОЙКИ (заполни) ============================
BOT_TOKEN = os.getenv("BOT_TOKEN", "PUT_BOT_TOKEN_HERE")
ADMIN_IDS = [8928795056]  # твой Telegram ID (можно несколько через запятую)
STORE_NAME = "RESELL"  # название магазина
MANAGER_USERNAME = "Bossyakovski"  # менеджер без @ (кому писать после оплаты)
WEBAPP_URL = "https://hurricane-according-lets-heading.trycloudflare.com"  # публичный HTTPS-адрес этого сервера (пусто = без Mini App)
WEB_PORT = 8080

TON_WALLET = "UQAkG05vfrcjy1LGLGUyjSBktertk2Sj0cGqPpUBl_6QiK7g"
TONCENTER_API_KEY = ""  # необязательно
CRYPTOBOT_TOKEN = "" # токен из @CryptoBot -> Crypto Pay -> Create App (пусто = USDT выключен)

# Реквизиты для ручной оплаты (показываются клиенту). Пусто = способ выключен.
SBP_TEXT = "СБП по номеру: +7 900 000-00-00\nБанк: ... \nПолучатель: ..."
CARD_TEXT = "Карта: 0000 0000 0000 0000\nПолучатель: ..."

RESERVE_MINUTES = 30                     # сколько вещь держится за клиентом
TON_RUB_FALLBACK = 95.0                  # запасные курсы, если не удалось получить живой
USDT_RUB_FALLBACK = 92.0
DB_PATH = "shop.db"
PHOTO_DIR = Path("photos")
# =============================================================================
try:  # необязательно: файл local_settings.py рядом с ботом переопределяет настройки выше (секреты не затрутся при обновлении)
    from local_settings import *  # noqa: F401,F403
except ImportError:
    pass

logging.basicConfig(level=logging.INFO)
bot = Bot(BOT_TOKEN, default=DefaultBotProperties(parse_mode=ParseMode.HTML))
dp = Dispatcher(storage=MemoryStorage())
BOT_USERNAME = ""
HAS_STYLE = "style" in InlineKeyboardButton.model_fields

# Telegram custom emoji IDs supplied for CHROME STREET. These entities work in
# message text/captions; InlineKeyboardButton.text only accepts plain text.
CUSTOM_EMOJI = {
    '✈️': '5361600266225326825',
    '🏷': '5240228673738527951',
    '❌': '5210952531676504517',
    '🔄': '5260687119092817530',
    '🎁': '5203996991054432397',
    '🔔': '5458603043203327669',
    '💬': '5443038326535759644',
    '🛒': '5431499171045581032',
    '🌐': '5447410659077661506',
    '📦': '5463172695132745432',
    '✨': '5325547803936572038',
    '💳': '5267300544094948794',
    '🛍': '5193065010795911968',
    '🏠': '5465226866321268133',
    '🔍': '5188217332748527444',
    '👤': '5373012449597335010',
    '❤️': '5449505950283078474',
    '➕': '5226945370684140473',
    '✏️': '5395444784611480792',
    '🗑': '5258130763148172425',
    '📊': '5431577498364158238',
    '⚙️': '5341715473882955310',
    '◀️': '5256247952564825322',
    '☑️': '5454096630372379732',
    '📸': '5258205968025525531',
    '👑': '5467406098367521267',
    '💎': '5427168083074628963',
    '💵': '6213220344614882714',
    '📲': '5217961106554769883',
    '🧥': '5460944852646639103',
    '👕': '5291733917257181608',
    '🥼': '5357566712113801432',
    '👟': '5330166508687474838',
    '👜': '5380056101473492248',
 }

def chrome_text(value: str) -> str:
    """Render known symbols as the store's Telegram custom emoji entities."""
    for symbol, emoji_id in CUSTOM_EMOJI.items():
        value = value.replace(symbol, f'<tg-emoji emoji-id="{emoji_id}">{symbol}</tg-emoji>')
    return value
  # цветные кнопки есть в новом aiogram

CATS = ["hoodie", "tee", "jacket", "sneaker", "bag", "other"]
CAT_ALIASES = {"худи": "hoodie", "футболка": "tee", "куртка": "jacket", "кроссовки": "sneaker",
               "сумка": "bag", "другое": "other"}
COND_ALIASES = {"новая": "new", "как новое": "like", "отличное": "great", "хорошее": "good"}

TXT = {
    "ru": {
        "welcome": "🛍 <b>{store}</b>\n<i>Selected | shop</i>\n\n✨ Брендовая одежда, обувь и аксессуары с продолжением истории.\n\n📸 В карточках — реальные фото, размеры, состояние и цена. Выбирай в каталоге, а если нужны детали — пиши менеджеру 💬\n\n✨ Твоя следующая находка уже здесь.\n\n<b>С чего начнём?</b>",
        "btn_app": "Открыть каталог", "btn_chat": "Смотреть в чате", "btn_orders": "Мои заказы",
        "btn_lang": "Язык / Language", "btn_mgr": "Написать менеджеру",
        "cats_title": "🛍 <b>Что ищем?</b>\nВыберите категорию:", "all": "Все", "hoodie": "Худи", "tee": "Футболки",
        "jacket": "Куртки", "sneaker": "Кроссовки", "bag": "Сумки", "other": "Другое",
        "empty": "Здесь пока пусто. Скоро появятся новые вещи ✨", "size": "Размер", "cond": "Состояние",
        "one": "в единственном экземпляре", "buy": "Купить", "back": "К категориям",
        "c_new": "новая с биркой", "c_like": "как новое", "c_great": "отличное", "c_good": "хорошее",
        "gone": "Эту вещь уже купили, а второго такого экземпляра нет. Загляните в каталог за чем-то новым.",
        "order": "🧾 <b>Заказ №{id}</b>\n\n{lines}\n\n━━━━━━━━━━\nИтого: <b>{total}</b>\n\nКак удобнее оплатить? 👇",
        "m_ton": "TON", "m_usdt": "USDT", "m_sbp": "СБП", "m_card": "Карта", "cancel": "Отменить заказ",
        "cancelled": "Заказ №{id} отменён. Если передумаете, вещи ждут в каталоге.",
        "pay_ton": "💎 <b>Оплата в TON</b>\n\nСумма: <b>{amount} TON</b> (≈ {total})\n\n<b>Адрес кошелька:</b>\n<code>{wallet}</code>\n\n"
                   "⚠️ <b>Обязательно</b> укажите комментарий к переводу:\n<code>{comment}</code>\n\nПосле оплаты нажмите «Проверить оплату», подтверждение занимает около минуты. Вещь остаётся в каталоге до подтверждения платежа.",
        "pay_usdt": "💵 <b>Оплата в USDT</b>\n\nСумма: <b>{amount} USDT</b> (≈ {total})\n\nНажмите кнопку ниже: оплата пройдёт через CryptoBot. Потом вернитесь сюда и нажмите «Проверить оплату».",
        "usdt_off": "Оплата USDT сейчас недоступна.",
        "pay_manual": "<b>{title}</b>\n\nСумма: <b>{total}</b>\n\n{details}\n\n"
                      "⚠️ В комментарии к платежу укажите: <code>{comment}</code>\n\nПосле перевода нажмите «Я оплатил», и менеджер подтвердит заказ.",
        "btn_tonkeeper": "Оплатить в Tonkeeper", "btn_invoice": "Оплатить в CryptoBot",
        "btn_check": "Проверить оплату", "btn_iplaid": "Я оплатил",
        "not_found": "Платёж пока не виден в сети. Подождите 1–2 минуты и нажмите ещё раз.",
        "wait_review": "Спасибо! 🙌 Проверяем платёж, обычно это занимает несколько минут. Мы обязательно напишем вам.",
        "declined": "Платёж по заказу №{id} не подтверждён. Напишите менеджеру, мы всё уладим.",
        "success": "✅ <b>Заказ №{id} оплачен!</b>\n\nСпасибо за покупку ✨\nТеперь укажите данные доставки кнопкой ниже, и мы отправим заказ. Если есть вопросы, менеджер на связи.",
        "conflict": "Оплата получена, но эту вещь успели купить раньше. Напишите менеджеру: предложим замену или вернём деньги.",
        "mgr_msg": "Здравствуйте! Мой заказ №{id}: {items}. Оплата: {method}.",
        "orders_title": "📦 <b>Мои заказы</b>", "no_orders": "У вас пока нет заказов. Самое время заглянуть в каталог 🛍",
        "st_pending": "ждёт оплаты", "st_review": "на проверке", "st_paid": "оплачен",
        "st_expired": "истёк", "st_cancelled": "отменён",
        "lang_choose": "Выберите язык:", "lang_set": "Язык: русский 🇷🇺",
    },
    "en": {
        "welcome": "🛍 <b>{store}</b>\n<i>Selected | shop</i>\n\n✨ Branded clothing, shoes and accessories with a story still going.\n\n📸 Real photos, sizes, condition and price on every card. Browse the catalog — for more details, message the manager 💬\n\n✨ Your next find is already here.\n\n<b>Where shall we start?</b>",
        "btn_app": "Open catalog", "btn_chat": "Browse in chat", "btn_orders": "My orders",
        "btn_lang": "Язык / Language", "btn_mgr": "Message the manager",
        "cats_title": "🛍 <b>What are you after?</b>\nChoose a category:", "all": "All", "hoodie": "Hoodies", "tee": "T-shirts",
        "jacket": "Jackets", "sneaker": "Sneakers", "bag": "Bags", "other": "Other",
        "empty": "Nothing here yet. New pieces are coming soon ✨", "size": "Size", "cond": "Condition",
        "one": "one of one", "buy": "Buy", "back": "Categories",
        "c_new": "new with tag", "c_like": "like new", "c_great": "excellent", "c_good": "good",
        "gone": "This piece has just been bought, and there is no second one. Check the catalog for something new.",
        "order": "🧾 <b>Order #{id}</b>\n\n{lines}\n\n━━━━━━━━━━\nTotal: <b>{total}</b>\n\nHow would you like to pay? 👇",
        "m_ton": "TON", "m_usdt": "USDT", "m_sbp": "SBP", "m_card": "Card", "cancel": "Cancel order",
        "cancelled": "Order #{id} cancelled. If you change your mind, the pieces are waiting in the catalog.",
        "pay_ton": "💎 <b>Pay with TON</b>\n\nAmount: <b>{amount} TON</b> (≈ {total})\n\n<b>Wallet address:</b>\n<code>{wallet}</code>\n\n"
                   "⚠️ You <b>must</b> include this comment:\n<code>{comment}</code>\n\nAfter paying, tap “Check payment”, confirmation takes about a minute. The piece stays listed until payment is confirmed.",
        "pay_usdt": "💵 <b>Pay with USDT</b>\n\nAmount: <b>{amount} USDT</b> (≈ {total})\n\nTap the button below: payment goes through CryptoBot. Then come back here and tap “Check payment”.",
        "usdt_off": "USDT payment is unavailable right now.",
        "pay_manual": "<b>{title}</b>\n\nAmount: <b>{total}</b>\n\n{details}\n\n"
                      "⚠️ Put this in the payment comment: <code>{comment}</code>\n\nAfter paying, tap “I've paid” and the manager will confirm your order.",
        "btn_tonkeeper": "Pay in Tonkeeper", "btn_invoice": "Pay in CryptoBot",
        "btn_check": "Check payment", "btn_iplaid": "I've paid",
        "not_found": "We can't see the payment yet. Wait a minute or two and tap again.",
        "wait_review": "Thanks! 🙌 We are checking your payment, it usually takes a few minutes. We will message you.",
        "declined": "Payment for order #{id} was not confirmed. Message the manager and we will sort it out.",
        "success": "✅ <b>Order #{id} paid!</b>\n\nThank you for your purchase ✨\nNow add your delivery details with the button below and we will ship your order. Questions? The manager is one tap away.",
        "conflict": "Payment received, but this piece was bought just before you. Message the manager: we will offer a replacement or refund.",
        "mgr_msg": "Hello! My order #{id}: {items}. Payment: {method}.",
        "orders_title": "📦 <b>My orders</b>", "no_orders": "You have no orders yet. A good time to check the catalog 🛍",
        "st_pending": "awaiting payment", "st_review": "under review", "st_paid": "paid",
        "st_expired": "expired", "st_cancelled": "cancelled",
        "lang_choose": "Choose your language:", "lang_set": "Language: English 🇬🇧",
    },
}

for _lang in TXT:
    for _key, _value in TXT[_lang].items():
        TXT[_lang][_key] = chrome_text(_value)


# ------------------------------- база данных -------------------------------
def db():
    con = sqlite3.connect(DB_PATH)
    con.row_factory = sqlite3.Row
    return con


def init_db():
    with db() as con:
        con.execute("CREATE TABLE IF NOT EXISTS users(user_id INTEGER PRIMARY KEY, lang TEXT NOT NULL)")
        con.execute("""CREATE TABLE IF NOT EXISTS products(
            id INTEGER PRIMARY KEY AUTOINCREMENT, brand TEXT, title TEXT, size TEXT, cond TEXT,
            price INTEGER, cat TEXT, photo TEXT, status TEXT NOT NULL DEFAULT 'available',
            order_id INTEGER, created INTEGER, description TEXT DEFAULT '')""")
        # Добавляем описание и в старую базу, если таблица уже существовала.
        product_columns = {row["name"] for row in con.execute("PRAGMA table_info(products)").fetchall()}
        if "description" not in product_columns:
            con.execute("ALTER TABLE products ADD COLUMN description TEXT DEFAULT ''")
        if "photos" not in product_columns:
            con.execute("ALTER TABLE products ADD COLUMN photos TEXT DEFAULT '[]'")
        con.execute("""CREATE TABLE IF NOT EXISTS orders(
            id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER, items TEXT, total INTEGER,
            status TEXT NOT NULL DEFAULT 'pending', method TEXT, crypto_amount REAL,
            invoice_id TEXT, created INTEGER, paid_at INTEGER)""")
        order_columns = {row["name"] for row in con.execute("PRAGMA table_info(orders)").fetchall()}
        for col, ddl in [("delivery_method", "TEXT"), ("delivery_name", "TEXT"), ("delivery_phone", "TEXT"),
                         ("delivery_address", "TEXT"), ("tracking", "TEXT"), ("ship_status", "TEXT DEFAULT 'new'")]:
            if col not in order_columns:
                con.execute(f"ALTER TABLE orders ADD COLUMN {col} {ddl}")
        # Старые резервы от предыдущей версии больше не нужны: корзина/заказ
        # не должны скрывать товар до фактического подтверждения оплаты.
        con.execute("UPDATE products SET status='available', order_id=NULL WHERE status='reserved'")
        con.execute("""CREATE TABLE IF NOT EXISTS settings(
            key TEXT PRIMARY KEY, value TEXT NOT NULL DEFAULT '')""")
        # Сидим реквизиты из конфига, если в базе ещё пусто.
        for key, val in (("sbp_text", SBP_TEXT), ("card_text", CARD_TEXT)):
            row = con.execute("SELECT value FROM settings WHERE key=?", (key,)).fetchone()
            if row is None:
                con.execute("INSERT INTO settings(key, value) VALUES(?, ?)", (key, val or ""))


def now() -> int:
    return int(time.time())


def esc(s) -> str:
    return html.escape(str(s))


def money(n) -> str:
    return f"{int(n):,}".replace(",", " ") + " ₽"


def ensure_user(u):
    with db() as con:
        if not con.execute("SELECT 1 FROM users WHERE user_id=?", (u.id,)).fetchone():
            code = (u.language_code or "en").lower()
            lang = "ru" if code.startswith(("ru", "uk", "be", "kk")) else "en"
            con.execute("INSERT INTO users VALUES(?,?)", (u.id, lang))


def get_lang(uid: int) -> str:
    with db() as con:
        r = con.execute("SELECT lang FROM users WHERE user_id=?", (uid,)).fetchone()
    return r["lang"] if r else "ru"


def tr(uid: int, key: str, **kw) -> str:
    s = TXT[get_lang(uid)][key]
    return s.format(**kw) if kw else s


def get_setting(key: str, default: str = "") -> str:
    with db() as con:
        row = con.execute("SELECT value FROM settings WHERE key=?", (key,)).fetchone()
    return (row["value"] if row and row["value"] is not None else default) or ""


def set_setting(key: str, value: str) -> None:
    with db() as con:
        con.execute(
            "INSERT INTO settings(key, value) VALUES(?, ?) "
            "ON CONFLICT(key) DO UPDATE SET value=excluded.value",
            (key, value),
        )


def pay_details(method: str) -> str:
    """Актуальные реквизиты СБП/карты из админки (с запасным значением из конфига)."""
    if method == "sbp":
        return get_setting("sbp_text", SBP_TEXT)
    if method == "card":
        return get_setting("card_text", CARD_TEXT)
    return ""


# Для каждой кнопки:  ключ: ("обычный эмодзи на случай если ID пустой", "ID кастомного эмодзи")
# Пустой ID = покажется обычный эмодзи. Вставь свои ID вместо пустых "".
BUTTON_EMOJI = {
    # --- категории каталога ---
    "c:all":      ("🛍", "5193065010795911968"),
    "c:hoodie": ("🧥", "5460944852646639103"),   # <- ID эмодзи для худи
    "c:tee": ("👕", "5291733917257181608"),   # <- ID эмодзи для футболок
    "c:jacket": ("🥼", "5357566712113801432"),   # <- ID эмодзи для курток
    "c:sneaker": ("👟", "5330166508687474838"),   # <- ID эмодзи для кроссовок
    "c:bag": ("👜", "5380056101473492248"),   # <- ID эмодзи для сумок
    "c:other":    ("✨", "5325547803936572038"),
    # --- способы оплаты ---
    "pay:ton": ("💎", "5427168083074628963"),   # <- ID эмодзи для TON
    "pay:usdt": ("💵", "6213220344614882714"),   # <- ID эмодзи для USDT
    "pay:sbp": ("📲", "5217961106554769883"),   # <- ID эмодзи для СБП
    "pay:card":   ("💳", "5267300544094948794"),
    # --- меню и админка (твои уже заданные ID) ---
    "cats":         ("🛍", "5193065010795911968"),
    "orders":       ("📦", "5463172695132745432"),
    "dl":          ("📦", "5463172695132745432"),
    "f:menu":      ("🔍", "5188217332748527444"),
    "lang":         ("🌐", "5447410659077661506"),
    "btn_app":      ("🛍", "5193065010795911968"),
    "btn_mgr":      ("💬", "5443038326535759644"),
    "cart":         ("🛒", "5431499171045581032"),
    "cancel":       ("❌", "5210952531676504517"),
    "adm:add":      ("➕", "5226945370684140473"),
    "adm:products": ("📦", "5463172695132745432"),
    "adm:orders":   ("📦", "5463172695132745432"),
    "adm:stats":    ("📊", "5431577498364158238"),
    "adm:edit":     ("✏️", "5395444784611480792"),
    "adm:del":      ("🗑", "5258130763148172425"),
    "adm:hide":     ("🏷", "5240228673738527951"),
    "adm:show":     ("🔄", "5260687119092817530"),
}

HAS_ICON = "icon_custom_emoji_id" in InlineKeyboardButton.model_fields


def emoji_key(cb: str) -> str:
    """Из callback_data делает ключ для BUTTON_EMOJI: pay:15:ton -> pay:ton, c:hoodie:0 -> c:hoodie."""
    p = cb.split(":")
    if p[0] == "pay" and len(p) == 3:
        return f"pay:{p[2]}"
    if p[0] in ("c", "adm", "f") and len(p) >= 2:
        return f"{p[0]}:{p[1]}"
    return p[0]


def b(kb, text, style=None, icon=None, **kw):
    """Кнопка: цвет (style) + кастомный эмодзи слева от текста (если задан ID), иначе обычный."""
    uni, cid = BUTTON_EMOJI.get(icon or emoji_key(kw.get("callback_data", "")), ("", ""))
    extra = {"style": style} if (style and HAS_STYLE) else {}
    if cid and HAS_ICON:
        extra["icon_custom_emoji_id"] = cid
    elif uni and not str(text).startswith(uni):
        text = f"{uni} {text}"
    kb.button(text=text, **extra, **kw)


def release_expired():
    """Закрывает старые неоплаченные заказы, не скрывая товары с витрины."""
    with db() as con:
        olds = con.execute("SELECT id FROM orders WHERE status='pending' AND created<=?",
                           (now() - RESERVE_MINUTES * 60,)).fetchall()
        for o in olds:
            con.execute("UPDATE orders SET status='expired' WHERE id=?", (o["id"],))


def available(cat=None):
    release_expired()
    q, args = "SELECT * FROM products WHERE status='available'", []
    if cat and cat != "all":
        q += " AND cat=?"
        args.append(cat)
    with db() as con:
        return con.execute(q + " ORDER BY id DESC", args).fetchall()


def get_order(oid: int):
    with db() as con:
        return con.execute("SELECT * FROM orders WHERE id=?", (oid,)).fetchone()


def order_products(o):
    ids = [int(x) for x in o["items"].split(",") if x]
    with db() as con:
        return [con.execute("SELECT * FROM products WHERE id=?", (i,)).fetchone() for i in ids]


def make_order(uid: int, pids: list):
    release_expired()
    pids = list(dict.fromkeys(pids))
    if not pids:
        return None
    marks = ",".join("?" * len(pids))
    with db() as con:
        rows = con.execute(f"SELECT * FROM products WHERE id IN ({marks}) AND status='available'", pids).fetchall()
        if len(rows) != len(pids):
            return None
        total = sum(r["price"] for r in rows)
        # Корзина/создание заказа не резервируют и не снимают товар с витрины.
        # Победитель определяется атомарно в момент подтверждения оплаты.
        cur = con.execute("INSERT INTO orders(user_id, items, total, created) VALUES(?,?,?,?)",
                          (uid, ",".join(map(str, pids)), total, now()))
        oid = cur.lastrowid
    return oid


# --------------------------------- курсы ---------------------------------
_rates = {"ts": 0.0, "TON": TON_RUB_FALLBACK, "USDT": USDT_RUB_FALLBACK}


async def get_rates():
    if time.time() - _rates["ts"] < 300:
        return _rates
    try:
        async with aiohttp.ClientSession() as s:
            async with s.get("https://api.coingecko.com/api/v3/simple/price",
                             params={"ids": "the-open-network,tether", "vs_currencies": "rub"},
                             timeout=aiohttp.ClientTimeout(total=10)) as r:
                d = await r.json()
        _rates["TON"] = float(d["the-open-network"]["rub"])
        _rates["USDT"] = float(d["tether"]["rub"])
        _rates["ts"] = time.time()
    except Exception:
        logging.warning("не удалось получить курсы, использую запасные")
        _rates["ts"] = time.time() - 240  # повторить через минуту
    return _rates


# ------------------------------ карточки в чате ------------------------------
def photos_of(p) -> list:
    """Все фото товара (до 4); если список пуст, берём обложку."""
    try:
        gallery = json.loads(p["photos"] or "[]")
    except (KeyError, IndexError, ValueError, TypeError):
        gallery = []
    return gallery or [p["photo"]]


def card_text(p, lang: str) -> str:
    t = TXT[lang]
    cond = t.get("c_" + str(p["cond"]), p["cond"])
    try:
        desc = (p["description"] or "").strip()
    except (KeyError, IndexError):
        desc = ""
    text = (f"<b>{esc(p['brand'])}</b>\n{esc(p['title'])}\n\n"
            f"{t['size']}: <b>{esc(p['size'])}</b>  ·  {t['cond']}: <b>{esc(cond)}</b>\n")
    if desc:
        text += f"\n<i>{esc(desc[:350])}{'…' if len(desc) > 350 else ''}</i>\n"
    return text + f"\n<b>{money(p['price'])}</b>  ·  <i>{t['one']}</i>"


def cats_kb(uid: int):
    t = TXT[get_lang(uid)]
    kb = InlineKeyboardBuilder()
    b(kb, t["all"], "primary", callback_data="c:all:0")
    for c in CATS:
        b(kb, t[c], callback_data=f"c:{c}:0")
    b(kb, DT[get_lang(uid)]["menu"], callback_data="f:menu")
    kb.adjust(1, 2, 2, 2, 1)
    return kb.as_markup()


async def send_cats(target: Message, uid: int):
    await target.answer(tr(uid, "cats_title") + filters_note(uid), reply_markup=cats_kb(uid))


@dp.callback_query(F.data.startswith("c:"))
async def browse(c: CallbackQuery):
    parts = c.data.split(":")  # c:<категория>:<номер вещи>[:<номер фото>]
    cat, idx = parts[1], int(parts[2])
    ph = int(parts[3]) if len(parts) > 3 else 0
    uid, lang = c.from_user.id, get_lang(c.from_user.id)
    t = TXT[lang]
    items = apply_filters(available(cat), uid)
    if not items:
        await c.answer(DT[lang]["nothing"] if UF.get(uid) else t["empty"], show_alert=True)
        return
    idx = idx % len(items)
    p = items[idx]
    photos = photos_of(p)
    ph = ph % len(photos)
    kb = InlineKeyboardBuilder()
    rows = []
    if len(photos) > 1:  # листание фото одной вещи
        kb.button(text="◀", callback_data=f"c:{cat}:{idx}:{ph - 1}")
        kb.button(text=f"📸 {ph + 1}/{len(photos)}", callback_data="noop")
        kb.button(text="▶", callback_data=f"c:{cat}:{idx}:{ph + 1}")
        rows.append(3)
    if len(items) > 1:  # листание вещей
        kb.button(text="◀ " + ("Пред." if lang == "ru" else "Prev"), callback_data=f"c:{cat}:{idx - 1}")
        kb.button(text=f"{idx + 1}/{len(items)}", callback_data="noop")
        kb.button(text=("След." if lang == "ru" else "Next") + " ▶", callback_data=f"c:{cat}:{idx + 1}")
        rows.append(3)
    b(kb, t["buy"] + " · " + money(p["price"]), "success", callback_data=f"buy:{p['id']}")
    kb.button(text=t["back"], callback_data="cats")
    b(kb, DT[lang]["menu"], callback_data="f:menu")
    kb.adjust(*rows, 1, 2)
    caption = card_text(p, lang)
    try:
        await c.message.edit_media(InputMediaPhoto(media=photos[ph], caption=caption), reply_markup=kb.as_markup())
    except Exception:
        await c.message.answer_photo(photos[ph], caption=caption, reply_markup=kb.as_markup())
        try:
            await c.message.delete()
        except Exception:
            pass
    await c.answer()


@dp.callback_query(F.data == "noop")
async def noop(c: CallbackQuery):
    await c.answer()


@dp.callback_query(F.data == "cats")
async def to_cats(c: CallbackQuery):
    await send_cats(c.message, c.from_user.id)
    try:
        await c.message.delete()
    except Exception:
        pass
    await c.answer()


# ----------------------------- старт, язык, заказы -----------------------------
async def send_welcome(m: Message, uid: int):
    t = TXT[get_lang(uid)]
    kb = InlineKeyboardBuilder()
    if WEBAPP_URL:
        b(kb, t["btn_app"], "primary", icon="btn_app", web_app=WebAppInfo(url=WEBAPP_URL))
    b(kb, t["btn_chat"], "success", callback_data="cats")
    b(kb, t["btn_orders"], callback_data="orders")
    b(kb, t["btn_mgr"], icon="btn_mgr", url=f"https://t.me/{MANAGER_USERNAME}")
    b(kb, t["btn_lang"], callback_data="lang")
    kb.adjust(1)
    await m.answer(t["welcome"].format(store=esc(STORE_NAME)), reply_markup=kb.as_markup())


@dp.message(CommandStart())
async def start(m: Message, command: CommandObject, state: FSMContext):
    await state.clear()
    ensure_user(m.from_user)
    arg = command.args or ""
    if arg.startswith("cart_"):  # переход из Mini App
        try:
            pids = [int(x) for x in arg[5:].split("-") if x]
        except ValueError:
            pids = []
        if pids:
            return await start_checkout(m.from_user.id, pids[:10])
    await send_welcome(m, m.from_user.id)


@dp.message(Command("catalog"))
async def cmd_catalog(m: Message):
    ensure_user(m.from_user)
    await send_cats(m, m.from_user.id)


@dp.callback_query(F.data == "lang")
@dp.message(Command("lang"))
async def choose_lang(x):
    uid = x.from_user.id
    kb = InlineKeyboardBuilder()
    kb.button(text="Русский 🇷🇺", callback_data="setlang:ru")
    kb.button(text="English 🇬🇧", callback_data="setlang:en")
    kb.adjust(2)
    msg = x.message if isinstance(x, CallbackQuery) else x
    await msg.answer(TXT[get_lang(uid)]["lang_choose"], reply_markup=kb.as_markup())
    if isinstance(x, CallbackQuery):
        await x.answer()


@dp.callback_query(F.data.startswith("setlang:"))
async def set_lang(c: CallbackQuery):
    lang = c.data.split(":")[1]
    with db() as con:
        con.execute("INSERT INTO users VALUES(?,?) ON CONFLICT(user_id) DO UPDATE SET lang=excluded.lang",
                    (c.from_user.id, lang))
    await c.message.answer(TXT[lang]["lang_set"])
    await send_welcome(c.message, c.from_user.id)
    await c.answer()


@dp.callback_query(F.data == "orders")
@dp.message(Command("orders"))
async def my_orders(x):
    uid = x.from_user.id
    msg = x.message if isinstance(x, CallbackQuery) else x
    with db() as con:
        rows = con.execute("SELECT * FROM orders WHERE user_id=? ORDER BY id DESC LIMIT 8", (uid,)).fetchall()
    t = TXT[get_lang(uid)]
    if not rows:
        await msg.answer(t["no_orders"])
    else:
        lang = get_lang(uid)
        kb = InlineKeyboardBuilder()
        need = [o for o in rows if o["status"] == "paid" and not o["delivery_method"]]
        for o in need:
            b(kb, f"{DT[lang]['btn_delivery']} · №{o['id']}", "success", callback_data=f"dl:{o['id']}")
        kb.adjust(1)
        await msg.answer(t["orders_title"] + "\n\n" + "\n".join(order_line(o, lang) for o in rows),
                         reply_markup=kb.as_markup() if need else None)
    if isinstance(x, CallbackQuery):
        await x.answer()


# ---------------------------- оформление и оплата ----------------------------
@dp.callback_query(F.data.startswith("buy:"))
async def buy(c: CallbackQuery):
    ensure_user(c.from_user)
    await start_checkout(c.from_user.id, [int(c.data.split(":")[1])])
    await c.answer()


async def start_checkout(uid: int, pids: list):
    lang = get_lang(uid)
    t = TXT[lang]
    oid = make_order(uid, pids)
    if not oid:
        return await bot.send_message(uid, t["gone"])
    o = get_order(oid)
    lines = "\n".join(f"• {esc(p['brand'])} — {esc(p['title'])} ({esc(p['size'])}): {money(p['price'])}"
                      for p in order_products(o))
    kb = InlineKeyboardBuilder()
    b(kb, t["m_ton"], "primary", callback_data=f"pay:{oid}:ton")
    if CRYPTOBOT_TOKEN:
        b(kb, t["m_usdt"], "primary", callback_data=f"pay:{oid}:usdt")
    if pay_details("sbp").strip():
        b(kb, t["m_sbp"], "success", callback_data=f"pay:{oid}:sbp")
    if pay_details("card").strip():
        b(kb, t["m_card"], "success", callback_data=f"pay:{oid}:card")
    b(kb, t["cancel"], "danger", callback_data=f"cancel:{oid}")
    kb.adjust(2, 2, 1)
    await bot.send_message(uid, t["order"].format(id=oid, lines=lines, total=money(o["total"])),
                           reply_markup=kb.as_markup())


def own_order(c: CallbackQuery, oid: int):
    o = get_order(oid)
    return o if o and o["user_id"] == c.from_user.id else None


@dp.callback_query(F.data.startswith("cancel:"))
async def cancel(c: CallbackQuery):
    oid = int(c.data.split(":")[1])
    o = own_order(c, oid)
    if o and o["status"] in ("pending", "review"):
        with db() as con:
            con.execute("UPDATE orders SET status='cancelled' WHERE id=?", (oid,))
        await c.message.answer(tr(c.from_user.id, "cancelled", id=oid))
    await c.answer()


@dp.callback_query(F.data.startswith("pay:"))
async def pay(c: CallbackQuery):
    _, oid, method = c.data.split(":")
    oid = int(oid)
    uid = c.from_user.id
    o = own_order(c, oid)
    if not o or o["status"] != "pending":
        return await c.answer(tr(uid, "gone"), show_alert=True)
    lang = get_lang(uid)
    t = TXT[lang]
    rates = await get_rates()
    kb = InlineKeyboardBuilder()
    if method == "ton":
        amount = round(o["total"] / rates["TON"] + 0.005, 2)
        comment = f"shop{oid}"
        with db() as con:
            con.execute("UPDATE orders SET method='ton', crypto_amount=? WHERE id=?", (amount, oid))
        b(kb, t["btn_tonkeeper"], "primary",
          url=f"https://app.tonkeeper.com/transfer/{TON_WALLET}?amount={int(amount * 1e9)}&text={comment}")
        b(kb, t["btn_check"], "success", callback_data=f"chk:{oid}")
        text = t["pay_ton"].format(amount=amount, total=money(o["total"]), wallet=TON_WALLET,
                                   comment=comment, mins=RESERVE_MINUTES)
    elif method == "usdt" and CRYPTOBOT_TOKEN:
        amount = round(o["total"] / rates["USDT"] + 0.005, 2)
        try:
            res = await cryptobot("createInvoice", asset="USDT", amount=str(amount),
                                  description=f"Order {oid}", payload=str(oid), expires_in=RESERVE_MINUTES * 60)
            inv = res["result"]
        except Exception:
            logging.exception("cryptobot error")
            return await c.answer(t["usdt_off"], show_alert=True)
        with db() as con:
            con.execute("UPDATE orders SET method='usdt', crypto_amount=?, invoice_id=? WHERE id=?",
                        (amount, str(inv["invoice_id"]), oid))
        b(kb, t["btn_invoice"], "primary", url=inv["bot_invoice_url"])
        b(kb, t["btn_check"], "success", callback_data=f"chk:{oid}")
        text = t["pay_usdt"].format(amount=amount, total=money(o["total"]))
    elif method in ("sbp", "card"):
        with db() as con:
            con.execute("UPDATE orders SET method=? WHERE id=?", (method, oid))
        b(kb, t["btn_iplaid"], "success", callback_data=f"paid:{oid}")
        details = pay_details(method)
        if not details.strip():
            return await c.answer("Этот способ оплаты сейчас недоступен.", show_alert=True)
        text = t["pay_manual"].format(title=t["m_" + method], total=money(o["total"]),
                                      details=esc(details), comment=f"shop{oid}")
    else:
        return await c.answer(t["usdt_off"], show_alert=True)
    kb.adjust(1)
    await c.message.answer(text, reply_markup=kb.as_markup())
    await c.answer()


async def toncenter_paid(comment: str, amount: float) -> bool:
    headers = {"X-API-Key": TONCENTER_API_KEY} if TONCENTER_API_KEY else {}
    async with aiohttp.ClientSession() as s:
        async with s.get("https://toncenter.com/api/v2/getTransactions",
                         params={"address": TON_WALLET, "limit": 50}, headers=headers,
                         timeout=aiohttp.ClientTimeout(total=20)) as r:
            data = await r.json()
    if not data.get("ok"):
        return False
    need = int(amount * 1e9) - 10_000_000  # допуск 0.01 TON
    for tx in data.get("result", []):
        msg = tx.get("in_msg") or {}
        if (msg.get("message") or "").strip() == comment and int(msg.get("value") or 0) >= need:
            return True
    return False


async def cryptobot(method: str, **params):
    async with aiohttp.ClientSession() as s:
        async with s.post(f"https://pay.crypt.bot/api/{method}", json=params,
                          headers={"Crypto-Pay-API-Token": CRYPTOBOT_TOKEN},
                          timeout=aiohttp.ClientTimeout(total=20)) as r:
            data = await r.json()
    if not data.get("ok"):
        raise RuntimeError(str(data))
    return data


async def cryptobot_paid(invoice_id: str) -> bool:
    res = await cryptobot("getInvoices", invoice_ids=invoice_id)
    r = res["result"]
    items = r["items"] if isinstance(r, dict) else r
    return bool(items) and items[0].get("status") == "paid"


@dp.callback_query(F.data.startswith("chk:"))
async def check(c: CallbackQuery):
    oid = int(c.data.split(":")[1])
    uid = c.from_user.id
    o = own_order(c, oid)
    if not o:
        return await c.answer()
    if o["status"] == "paid":
        return await c.answer("✅", show_alert=True)
    try:
        if o["method"] == "ton":
            ok = await toncenter_paid(f"shop{oid}", o["crypto_amount"])
        elif o["method"] == "usdt":
            ok = await cryptobot_paid(o["invoice_id"])
        else:
            ok = False
    except Exception:
        logging.exception("payment check error")
        ok = False
    if not ok:
        return await c.answer(tr(uid, "not_found"), show_alert=True)
    await finalize(oid)
    await c.answer()


@dp.callback_query(F.data.startswith("paid:"))
async def i_paid(c: CallbackQuery):
    oid = int(c.data.split(":")[1])
    o = own_order(c, oid)
    if not o or o["status"] not in ("pending", "review"):
        return await c.answer()
    with db() as con:
        con.execute("UPDATE orders SET status='review' WHERE id=?", (oid,))
    await c.message.answer(tr(c.from_user.id, "wait_review"))
    kb = InlineKeyboardBuilder()
    b(kb, "✅ Подтвердить", "success", callback_data=f"ok:{oid}")
    b(kb, "❌ Не пришло", "danger", callback_data=f"no:{oid}")
    kb.adjust(2)
    u = c.from_user
    await notify_admins(f"💳 Клиент <a href='tg://user?id={u.id}'>{esc(u.full_name)}</a> нажал «Я оплатил»\n"
                        f"Заказ №{oid}, {money(o['total'])}, способ: {o['method']}\nПроверь поступление.",
                        kb.as_markup())
    await c.answer()


@dp.callback_query(F.data.startswith(("ok:", "no:")))
async def admin_review(c: CallbackQuery):
    if c.from_user.id not in ADMIN_IDS:
        return await c.answer()
    action, oid = c.data.split(":")
    oid = int(oid)
    o = get_order(oid)
    if not o or o["status"] == "paid":
        return await c.answer("Уже обработан", show_alert=True)
    if action == "ok":
        await finalize(oid)
        await c.message.edit_text(c.message.html_text + "\n\n✅ Подтверждено")
    else:
        with db() as con:
            con.execute("UPDATE orders SET status='pending' WHERE id=?", (oid,))
        await bot.send_message(o["user_id"], tr(o["user_id"], "declined", id=oid))
        await c.message.edit_text(c.message.html_text + "\n\n❌ Отклонено")
    await c.answer()


async def finalize(oid: int):
    """Подтверждённая оплата: атомарно продаёт доступные товары заказа."""
    conflict = False
    with db() as con:
        con.execute("BEGIN IMMEDIATE")
        o = con.execute("SELECT * FROM orders WHERE id=?", (oid,)).fetchone()
        if not o or o["status"] == "paid":
            return
        ids = [int(x) for x in o["items"].split(",") if x]
        if not ids:
            return
        marks = ",".join("?" for _ in ids)
        rows = con.execute(f"SELECT id,status FROM products WHERE id IN ({marks})", ids).fetchall()
        available_ids = {r["id"] for r in rows if r["status"] == "available"}
        conflict = len(rows) != len(ids) or len(available_ids) != len(ids)
        con.execute("UPDATE orders SET status='paid', paid_at=? WHERE id=?", (now(), oid))
        if not conflict:
            con.execute(f"UPDATE products SET status='sold', order_id=? WHERE id IN ({marks}) AND status='available'", [oid] + ids)
    uid = o["user_id"]
    lang = get_lang(uid)
    t = TXT[lang]
    items = ", ".join(f"{p['brand']} {p['title']} ({p['size']})" for p in order_products(o) if p)
    method = (o["method"] or "").upper()
    kb = InlineKeyboardBuilder()
    text = t["mgr_msg"].format(id=oid, items=items, method=method)
    if not conflict:
        b(kb, DT[lang]["btn_delivery"], "success", callback_data=f"dl:{oid}")
    b(kb, t["btn_mgr"], "primary", url=f"https://t.me/{MANAGER_USERNAME}?text={quote(text)}")
    await bot.send_message(uid, t["conflict"] if conflict else t["success"].format(id=oid), reply_markup=kb.as_markup())
    await notify_admins(chrome_text(f"💰 Оплачен заказ №{oid} на {money(o['total'])} ({method})\n{esc(items)}")
                        + ("\n⚠️ Товар уже купили в другом заказе — требуется возврат или согласование замены." if conflict else "")
                        + f"\nКлиент: <a href='tg://user?id={uid}'>{uid}</a>")


async def notify_admins(text: str, markup=None):
    for aid in ADMIN_IDS:
        try:
            await bot.send_message(aid, text, reply_markup=markup)
        except Exception:
            logging.warning("не удалось написать админу %s", aid)


# --------------------------------- админка ---------------------------------
class AdminAddStates(StatesGroup):
    photo = State()
    details = State()
    edit_details = State()
    pay_sbp = State()
    pay_card = State()


def is_admin(m: Message) -> bool:
    return bool(m.from_user and m.from_user.id in ADMIN_IDS)


def admin_kb():
    kb = InlineKeyboardBuilder()
    kb.button(text="➕ Добавить товар", callback_data="adm:add")
    kb.button(text="📦 Мои товары", callback_data="adm:products")
    kb.button(text="📦 Заказы", callback_data="adm:orders")
    kb.button(text="📊 Статистика", callback_data="adm:stats")
    kb.button(text="💳 Реквизиты оплаты", callback_data="adm:pay")
    kb.adjust(1, 2, 1, 1)
    return kb.as_markup()


def admin_product_kb(pid: int, status: str):
    kb = InlineKeyboardBuilder()
    kb.button(text="✏️ Изменить данные", callback_data=f"adm:edit:{pid}")
    if status == "available":
        kb.button(text="🗑 Удалить", callback_data=f"adm:del:{pid}")
        kb.button(text="⏸ Снять с продажи", callback_data=f"adm:hide:{pid}")
    else:
        kb.button(text="✅ Вернуть в продажу", callback_data=f"adm:show:{pid}")
        kb.button(text="🗑 Удалить", callback_data=f"adm:del:{pid}")
    kb.button(text="⬅️ В меню", callback_data="adm:home")
    kb.adjust(1, 2, 1)
    return kb.as_markup()


@dp.message(Command("admin"))
async def admin_help(m: Message, state: FSMContext):
    if not is_admin(m):
        return
    await state.clear()
    await m.answer(chrome_text(f"👑 <b>{esc(STORE_NAME)} · Панель управления</b>\n➕ Добавление товаров · 📦 Заказы · 📊 Статистика\nВыбери действие:"), reply_markup=admin_kb())


@dp.callback_query(F.data.startswith("adm:"))
async def admin_actions(c: CallbackQuery, state: FSMContext):
    if c.from_user.id not in ADMIN_IDS:
        return await c.answer("Нет доступа", show_alert=True)
    data = c.data.split(":")
    action = data[1]
    # This callback must be handled here because this broad adm:* handler
    # is registered before the dedicated donephotos handler below.
    if action == "donephotos":
        form = await state.get_data()
        photos = form.get("photos", [])
        if not photos:
            return await c.answer("Сначала отправь хотя бы одно фото", show_alert=True)
        await state.set_state(AdminAddStates.details)
        await c.answer()
        return await c.message.answer(
            "<b>Теперь заполним карточку</b>\n\n"
            "Отправь одной строкой через вертикальную черту |\n"
            "<code>Бренд | Название | Размер | Состояние | Цена | Категория | Описание</code>\n\n"
            "Пример:\n<code>NIKE | Винтажная куртка | M | отличное | 8500 | куртка | Оригинальная вещь, без дефектов</code>\n\n"
            "Категории: худи, футболка, куртка, кроссовки, сумка, другое.", parse_mode="HTML")
    await c.answer()
    if action == "home":
        await state.clear()
        return await c.message.edit_text(chrome_text(f"👑 <b>{esc(STORE_NAME)} · Панель управления</b>\n➕ Добавление товаров · 📦 Заказы · 📊 Статистика\nВыбери действие:"), reply_markup=admin_kb())
    if action == "add":
        await state.set_state(AdminAddStates.photo)
        await state.update_data(photos=[])
        return await c.message.answer(
            "<b>Новая карточка товара</b>\n\n"
            "📸 Отправляй фотографии вещи по одной — можно добавить до 4 снимков.\n"
            "Покажи общий вид, детали и состояние.\n\n"
            "Когда закончишь, нажми «Готово».",
            reply_markup=InlineKeyboardBuilder().button(text="Готово · перейти к описанию", callback_data="adm:donephotos").as_markup())
    if action == "products":
        with db() as con:
            rows = con.execute("SELECT id,brand,title,size,price,status FROM products ORDER BY id DESC LIMIT 30").fetchall()
        if not rows:
            return await c.message.answer("Каталог пока пуст.", reply_markup=admin_kb())
        for p in rows:
            await c.message.answer(
                f"<b>#{p['id']} · {esc(p['brand'])}</b>\n{esc(p['title'])} · {esc(p['size'])}\n{money(p['price'])} · {esc(p['status'])}",
                reply_markup=admin_product_kb(p['id'], p['status']))
        return
    if action == "orders":
        with db() as con:
            rows = con.execute("SELECT * FROM orders ORDER BY id DESC LIMIT 20").fetchall()
        if not rows:
            return await c.message.answer("Заказов пока нет.", reply_markup=admin_kb())
        lines = [f"№{o['id']} · {money(o['total'])} · {esc(o['status'])} · {esc(o['method'] or '—')} · ID {o['user_id']}" for o in rows]
        await c.message.answer("<b>Последние заказы</b>\n" + "\n".join(lines), reply_markup=admin_kb())
        return await send_ship_queue(c, rows)
    if action == "stats":
        with db() as con:
            products = con.execute("SELECT COUNT(*) n FROM products").fetchone()["n"]
            available_n = con.execute("SELECT COUNT(*) n FROM products WHERE status='available'").fetchone()["n"]
            orders = con.execute("SELECT COUNT(*) n FROM orders").fetchone()["n"]
            paid = con.execute("SELECT COUNT(*) n FROM orders WHERE status='paid'").fetchone()["n"]
            revenue = con.execute("SELECT COALESCE(SUM(total),0) n FROM orders WHERE status='paid'").fetchone()["n"]
        return await c.message.answer(f"<b>Статистика</b>\nВсего товаров: {products}\nВ продаже: {available_n}\nЗаказов: {orders}\nОплачено: {paid}\nВыручка: {money(revenue)}", reply_markup=admin_kb())
    if action == "pay":
        sbp = pay_details("sbp") or "— не задано —"
        card = pay_details("card") or "— не задано —"
        kb = InlineKeyboardBuilder()
        kb.button(text="✏️ Изменить СБП", callback_data="adm:pay_sbp")
        kb.button(text="✏️ Изменить карту", callback_data="adm:pay_card")
        kb.button(text="🗑 Выключить СБП", callback_data="adm:pay_off_sbp")
        kb.button(text="🗑 Выключить карту", callback_data="adm:pay_off_card")
        kb.button(text="⬅️ В меню", callback_data="adm:home")
        kb.adjust(2, 2, 1)
        return await c.message.answer(
            "💳 <b>Реквизиты оплаты</b>\n\n"
            f"<b>СБП</b>\n<code>{esc(sbp)}</code>\n\n"
            f"<b>Карта</b>\n<code>{esc(card)}</code>\n\n"
            "Пустой текст = способ скрыт у клиентов.\n"
            "Нажми кнопку, чтобы изменить или выключить.",
            reply_markup=kb.as_markup(),
        )
    if action == "pay_sbp":
        await state.set_state(AdminAddStates.pay_sbp)
        cur = pay_details("sbp") or "—"
        return await c.message.answer(
            "✏️ <b>Новые реквизиты СБП</b>\n\nОтправь текстом, как показывать клиенту.\n"
            f"Сейчас:\n<code>{esc(cur)}</code>\n\n"
            "Пример:\n<code>СБП по номеру: +7 900 000-00-00\nБанк: Т-Банк\nПолучатель: Иван И.</code>",
        )
    if action == "pay_card":
        await state.set_state(AdminAddStates.pay_card)
        cur = pay_details("card") or "—"
        return await c.message.answer(
            "✏️ <b>Новые реквизиты карты</b>\n\nОтправь текстом, как показывать клиенту.\n"
            f"Сейчас:\n<code>{esc(cur)}</code>\n\n"
            "Пример:\n<code>Карта: 2200 0000 0000 0000\nБанк: Т-Банк\nПолучатель: Иван И.</code>",
        )
    if action == "pay_off_sbp":
        set_setting("sbp_text", "")
        return await c.message.answer("СБП выключен — кнопка скрыта у клиентов.", reply_markup=admin_kb())
    if action == "pay_off_card":
        set_setting("card_text", "")
        return await c.message.answer("Оплата картой выключена — кнопка скрыта у клиентов.", reply_markup=admin_kb())
    if action == "edit" and len(data) == 3:
        pid = int(data[2])
        with db() as con:
            product = con.execute("SELECT * FROM products WHERE id=?", (pid,)).fetchone()
        if not product:
            return await c.message.answer("Товар не найден.")
        await state.set_state(AdminAddStates.edit_details)
        await state.update_data(edit_pid=pid)
        return await c.message.answer(
            f"✏️ Изменяем товар #{pid}. Отправь новые данные через `|`:\n"
            "<code>Бренд | Название | Размер | Состояние | Цена | Категория | Описание</code>\n\n"
            f"Сейчас: <code>{esc(product['brand'])} | {esc(product['title'])} | {esc(product['size'])} | {esc(product['cond'])} | {product['price']} | {esc(product['cat'])} | {esc(product['description'] or '')}</code>", parse_mode="HTML")
    if action == "del" and len(data) == 3:
        pid = int(data[2])
        kb = InlineKeyboardBuilder()
        kb.button(text="Да, удалить", callback_data=f"adm:delok:{pid}")
        kb.button(text="Отмена", callback_data="adm:products")
        kb.adjust(2)
        return await c.message.answer(f"Удалить товар #{pid}?", reply_markup=kb.as_markup())
    if action == "delok" and len(data) == 3:
        pid = int(data[2])
        with db() as con:
            con.execute("DELETE FROM products WHERE id=?", (pid,))
        (PHOTO_DIR / f"{pid}.jpg").unlink(missing_ok=True)
        return await c.message.answer(f"Товар #{pid} удалён.", reply_markup=admin_kb())
    if action in ("hide", "show") and len(data) == 3:
        pid = int(data[2])
        status = "hidden" if action == "hide" else "available"
        with db() as con:
            con.execute("UPDATE products SET status=?, order_id=NULL WHERE id=? AND status != 'reserved'", (status, pid))
        return await c.message.answer("Статус товара обновлён.", reply_markup=admin_kb())


@dp.message(AdminAddStates.photo, F.photo)
async def admin_receive_photo(m: Message, state: FSMContext):
    if not is_admin(m):
        return
    data = await state.get_data()
    photos = data.get("photos", [])
    file_id = m.photo[-1].file_id
    if file_id not in photos and len(photos) < 4:
        photos.append(file_id)
        await state.update_data(photos=photos, photo=photos[0])
    await m.answer(chrome_text(f"📸 Фото добавлено: <b>{len(photos)}/4</b>. Отправь ещё или нажми «Готово».") ,
                   reply_markup=InlineKeyboardBuilder().button(text="Готово · перейти к описанию", callback_data="adm:donephotos").as_markup())


@dp.callback_query(F.data == "adm:donephotos")
async def admin_done_photos(c: CallbackQuery, state: FSMContext):
    if c.from_user.id not in ADMIN_IDS:
        return await c.answer("Нет доступа", show_alert=True)
    data = await state.get_data()
    photos = data.get("photos", [])
    if not photos:
        return await c.answer("Сначала отправь хотя бы одно фото", show_alert=True)
    await state.set_state(AdminAddStates.details)
    await c.answer()
    await c.message.answer(
        "<b>Теперь заполним карточку</b>\n\n"
        "Отправь одной строкой через вертикальную черту |\n"
        "<code>Бренд | Название | Размер | Состояние | Цена | Категория | Описание</code>\n\n"
        "Пример:\n<code>NIKE | Винтажная куртка | M | отличное | 8500 | куртка | Оригинальная вещь, без дефектов</code>\n\n"
        "Категории: худи, футболка, куртка, кроссовки, сумка, другое.", parse_mode="HTML")


@dp.message(AdminAddStates.photo)
async def admin_need_photo(m: Message):
    if is_admin(m):
        await m.answer("Сначала отправь фотографию товара.")


@dp.message(AdminAddStates.details, F.text)
async def admin_receive_details(m: Message, state: FSMContext):
    if not is_admin(m):
        return
    parts = [x.strip() for x in m.text.split("|", 6)]
    if len(parts) != 7 or not parts[4].isdigit():
        return await m.answer("Не получилось разобрать данные. Проверь формат и отправь ещё раз:\n<code>Бренд | Название | Размер | Состояние | Цена | Категория | Описание</code>")
    brand, title, size, cond, price, cat, description = parts
    cat = CAT_ALIASES.get(cat.lower(), cat.lower())
    if cat not in CATS:
        return await m.answer("Неизвестная категория. Используй: худи, футболка, куртка, кроссовки, сумка или другое.")
    cond = COND_ALIASES.get(cond.lower(), cond)
    data = await state.get_data()
    with db() as con:
        photos = data.get("photos") or [data["photo"]]
        cur = con.execute("INSERT INTO products(brand,title,size,cond,price,cat,photo,created,description,photos) VALUES(?,?,?,?,?,?,?,?,?,?)",
                          (brand, title, size, cond, int(price), cat, photos[0], now(), description, json.dumps(photos, ensure_ascii=False)))
        pid = cur.lastrowid
    await state.clear()
    kb = InlineKeyboardBuilder()
    kb.button(text="➕ Добавить ещё", callback_data="adm:add")
    kb.button(text="📦 К товарам", callback_data="adm:products")
    kb.button(text="⚙️ В меню", callback_data="adm:home")
    kb.adjust(1)
    await m.answer(chrome_text(f"✨ <b>Карточка опубликована · #{pid}</b>\n{esc(brand)} — {esc(title)}\nРазмер: {esc(size)}\nЦена: <b>{money(price)}</b>\nФотографий: <b>{len(photos)}</b>\nОписание: {esc(description)}\n\nТовар уже доступен в каталоге."), reply_markup=kb.as_markup())


@dp.message(AdminAddStates.edit_details, F.text)
async def admin_update_details(m: Message, state: FSMContext):
    if not is_admin(m):
        return
    parts = [x.strip() for x in m.text.split("|", 6)]
    if len(parts) != 7 or not parts[4].isdigit():
        return await m.answer("Формат: Бренд | Название | Размер | Состояние | Цена | Категория | Описание")
    brand, title, size, cond, price, cat, description = parts
    cat = CAT_ALIASES.get(cat.lower(), cat.lower())
    if cat not in CATS:
        return await m.answer("Неизвестная категория. Используй: худи, футболка, куртка, кроссовки, сумка или другое.")
    cond = COND_ALIASES.get(cond.lower(), cond)
    data = await state.get_data()
    with db() as con:
        con.execute("UPDATE products SET brand=?,title=?,size=?,cond=?,price=?,cat=?,description=? WHERE id=?",
                    (brand, title, size, cond, int(price), cat, description, data["edit_pid"]))
    await state.clear()
    await m.answer(f"✅ Товар #{data['edit_pid']} обновлён.", reply_markup=admin_kb())


@dp.message(AdminAddStates.pay_sbp, F.text)
async def admin_save_sbp(m: Message, state: FSMContext):
    if not is_admin(m):
        return
    value = m.text.strip()[:800]
    set_setting("sbp_text", value)
    await state.clear()
    await m.answer(
        "✅ Реквизиты <b>СБП</b> сохранены.\n\n<code>" + esc(value) + "</code>",
        reply_markup=admin_kb(),
    )


@dp.message(AdminAddStates.pay_card, F.text)
async def admin_save_card(m: Message, state: FSMContext):
    if not is_admin(m):
        return
    value = m.text.strip()[:800]
    set_setting("card_text", value)
    await state.clear()
    await m.answer(
        "✅ Реквизиты <b>карты</b> сохранены.\n\n<code>" + esc(value) + "</code>",
        reply_markup=admin_kb(),
    )


@dp.message(AdminAddStates.details)
async def admin_need_details(m: Message):
    if is_admin(m):
        await m.answer("Отправь данные товара текстом в формате, который указан выше.")


@dp.message(Command("products"))
async def list_products(m: Message):
    if not is_admin(m):
        return
    with db() as con:
        rows = con.execute("SELECT * FROM products ORDER BY id DESC LIMIT 40").fetchall()
    if not rows:
        return await m.answer("Вещей нет. Открой /admin, чтобы добавить товар.")
    for p in rows:
        await m.answer(f"{p['id']}. {esc(p['brand'])} — {esc(p['title'])}, {esc(p['size'])}, {money(p['price'])} [{esc(p['status'])}]",
                        reply_markup=admin_product_kb(p['id'], p['status']))


@dp.message(Command("del"))
async def del_product(m: Message, command: CommandObject):
    if not is_admin(m):
        return
    if not (command.args or "").strip().isdigit():
        return await m.answer("Использование: /del ID")
    pid = int(command.args)
    with db() as con:
        con.execute("DELETE FROM products WHERE id=?", (pid,))
    (PHOTO_DIR / f"{pid}.jpg").unlink(missing_ok=True)
    await m.answer("Удалено.")


@dp.message(Command("allorders"))
async def all_orders(m: Message):
    if not is_admin(m):
        return
    with db() as con:
        rows = con.execute("SELECT * FROM orders ORDER BY id DESC LIMIT 20").fetchall()
    await m.answer("\n".join(f"№{o['id']} · {money(o['total'])} · {esc(o['status'])} · {esc(o['method'] or '-')} · {o['user_id']}" for o in rows) or "Заказов нет.")


# ------------------------------ Mini App сервер ------------------------------
async def web_index(request):
    return web.FileResponse(Path(__file__).with_name("index.html"), headers={"Cache-Control": "no-cache"})


async def web_products(request):
    items = available()
    return web.json_response({
        "bot": BOT_USERNAME, "store": STORE_NAME,
        "products": [{"id": p["id"], "brand": p["brand"], "title": p["title"], "size": p["size"],
                      "cond": p["cond"], "price": p["price"], "cat": p["cat"], "description": p["description"] or "",
                      "images": list(range(len(json.loads(p["photos"] or "[]") or [p["photo"]])))} for p in items]},
        headers={"Cache-Control": "no-store"})


async def web_img(request):
    try:
        pid = int(request.match_info["pid"])
        idx = int(request.match_info.get("idx", "0"))
    except ValueError:
        raise web.HTTPNotFound()
    with db() as con:
        row = con.execute("SELECT photo, photos FROM products WHERE id=?", (pid,)).fetchone()
    if not row:
        raise web.HTTPNotFound()
    try:
        gallery = json.loads(row["photos"] or "[]") if row["photos"] else []
    except (TypeError, json.JSONDecodeError):
        gallery = []
    if not gallery and row["photo"]:
        gallery = [row["photo"]]
    if idx < 0 or idx >= len(gallery):
        raise web.HTTPNotFound()
    path = PHOTO_DIR / f"{pid}_{idx}.jpg"
    if not path.exists():
        PHOTO_DIR.mkdir(exist_ok=True)
        await bot.download(gallery[idx], destination=path)
    return web.FileResponse(path, headers={"Cache-Control": "public, max-age=86400"})


async def run_web():
    app = web.Application()
    app.router.add_get("/", web_index)
    app.router.add_get("/api/products", web_products)
    app.router.add_get("/img/{pid}", web_img)
    app.router.add_get("/img/{pid}/{idx}", web_img)
    runner = web.AppRunner(app)
    await runner.setup()
    await web.TCPSite(runner, "0.0.0.0", WEB_PORT).start()
    logging.info("Mini App слушает порт %s", WEB_PORT)


async def watcher():
    while True:
        try:
            release_expired()
        except Exception:
            logging.exception("watcher")
        await asyncio.sleep(60)


# Помощник: админ отправляет боту сообщение с кастомными эмодзи, бот отвечает их ID.
# Вставляй в самый конец файла, ПЕРЕД  async def main():
# ============================ доставка заказов ============================
DELIVERY = {  # ключ: (RU, EN, нужен ли адрес)
    "cdek": ("СДЭК", "CDEK", True), "post": ("Почта России", "Russian Post", True),
    "courier": ("Курьер", "Courier", True), "pickup": ("Самовывоз", "Pickup", False),
}

DT = {
    "ru": {
        "ask_method": "📦 <b>Доставка · заказ №{id}</b>\n\nКак вам удобнее получить вещь?",
        "ask_name": "👤 Напишите <b>имя и фамилию получателя</b>:",
        "ask_phone": "📲 Напишите <b>телефон получателя</b> (с кодом страны):",
        "bad_phone": "Не похоже на номер телефона. Попробуйте ещё раз, например +7 900 000-00-00:",
        "ask_addr": "🏠 Напишите <b>город и адрес</b> (улица, дом, квартира) или <b>номер пункта выдачи</b>:",
        "saved": "✅ <b>Данные доставки сохранены</b>\n\nЗаказ №{id} · {method}\nМы отправим вещь и пришлём трек-номер сюда.",
        "saved_pickup": "✅ <b>Самовывоз оформлен</b>\n\nЗаказ №{id}. Менеджер свяжется с вами и согласует время и место.",
        "btn_cancel": "Отмена", "btn_delivery": "Указать доставку",
        "cancelled": "Хорошо. Вернуться к доставке можно в разделе «Мои заказы».",
        "shipped": "🚚 <b>Заказ №{id} отправлен!</b>\n\nСпособ: {method}\nТрек-номер: {track}",
        "no_track": "без трека",
        "delivered": "✨ <b>Заказ №{id} доставлен.</b>\n\nСпасибо, что выбрали {store}! Будем рады отзыву.",
        "sh_none": "укажите доставку", "sh_new": "готовится к отправке", "sh_shipped": "отправлен", "sh_delivered": "доставлен",
        "track": "трек",
        "panel": "🔍 <b>Поиск и фильтры</b>\n\n{active}\n\nЧто настроить?", "none_active": "Фильтры не заданы.",
        "active": "Сейчас: {text}", "size": "Размер", "brand": "Бренд", "price": "Цена", "query": "Поиск", "any": "Любой",
        "pick_size": "Выберите размер:", "pick_brand": "Выберите бренд:", "pick_price": "Выберите цену:",
        "ask_q": "🔍 Напишите, что ищете: бренд, название или слово из описания.",
        "found": "Нашёл вещей: <b>{n}</b>", "nothing": "Ничего не найдено. Измените или сбросьте фильтры.",
        "show": "Показать ({n})", "reset": "Сбросить", "menu": "Поиск и фильтры",
    },
    "en": {
        "ask_method": "📦 <b>Delivery · order #{id}</b>\n\nHow would you like to receive it?",
        "ask_name": "👤 Send the <b>recipient's full name</b>:",
        "ask_phone": "📲 Send the <b>recipient's phone</b> (with country code):",
        "bad_phone": "That doesn't look like a phone number. Try again, e.g. +1 555 000 0000:",
        "ask_addr": "🏠 Send the <b>city and address</b> (street, house, flat) or the <b>pickup point number</b>:",
        "saved": "✅ <b>Delivery details saved</b>\n\nOrder #{id} · {method}\nWe will ship it and send the tracking number here.",
        "saved_pickup": "✅ <b>Pickup arranged</b>\n\nOrder #{id}. The manager will contact you to agree on time and place.",
        "btn_cancel": "Cancel", "btn_delivery": "Add delivery",
        "cancelled": "OK. You can come back to delivery in “My orders”.",
        "shipped": "🚚 <b>Order #{id} has shipped!</b>\n\nMethod: {method}\nTracking number: {track}",
        "no_track": "no tracking", 
        "delivered": "✨ <b>Order #{id} delivered.</b>\n\nThank you for choosing {store}! We would love a review.",
        "sh_none": "add delivery", "sh_new": "preparing to ship", "sh_shipped": "shipped", "sh_delivered": "delivered",
        "track": "track",
        "panel": "🔍 <b>Search & filters</b>\n\n{active}\n\nWhat would you like to set?", "none_active": "No filters set.",
        "active": "Now: {text}", "size": "Size", "brand": "Brand", "price": "Price", "query": "Search", "any": "Any",
        "pick_size": "Choose a size:", "pick_brand": "Choose a brand:", "pick_price": "Choose a price:",
        "ask_q": "🔍 Tell me what you are looking for: a brand, a name or a word from the description.",
        "found": "Pieces found: <b>{n}</b>", "nothing": "Nothing found. Change or reset the filters.",
        "show": "Show ({n})", "reset": "Reset", "menu": "Search & filters",
    },
}


def dtr(uid: int, key: str, **kw) -> str:
    s = DT[get_lang(uid)][key]
    return chrome_text(s.format(**kw) if kw else s)


def dname(lang: str, key) -> str:
    if key not in DELIVERY:
        return "—"
    ru, en, _ = DELIVERY[key]
    return ru if lang == "ru" else en


def order_line(o, lang: str) -> str:
    t, d = TXT[lang], DT[lang]
    line = f"№{o['id']} · {money(o['total'])} · {t['st_' + o['status']]}"
    if o["status"] == "paid":
        line += " · " + (d["sh_" + (o["ship_status"] or "new")] if o["delivery_method"] else d["sh_none"])
        if o["tracking"]:
            line += f" · {d['track']}: <code>{esc(o['tracking'])}</code>"
    return line


def admin_order_card(o):
    uid = o["user_id"]
    items = ", ".join(f"{p['brand']} {p['title']} ({p['size']})" for p in order_products(o) if p)
    lines = [f"📦 <b>Заказ №{o['id']}</b> · {money(o['total'])} · {esc((o['method'] or '').upper())}", esc(items)]
    if o["delivery_method"]:
        lines += [f"Доставка: <b>{esc(dname('ru', o['delivery_method']))}</b>",
                  f"Получатель: {esc(o['delivery_name'] or '—')} · {esc(o['delivery_phone'] or '—')}"]
        if o["delivery_address"]:
            lines.append(f"Адрес: {esc(o['delivery_address'])}")
    else:
        lines.append("Данные доставки пока не указаны.")
    if o["tracking"]:
        lines.append(f"Трек: <code>{esc(o['tracking'])}</code>")
    st = {"new": "ждёт отправки", "shipped": "отправлен", "delivered": "доставлен"}[o["ship_status"] or "new"]
    lines.append(f"Статус: <b>{st}</b>\nКлиент: <a href='tg://user?id={uid}'>{uid}</a>")
    kb = InlineKeyboardBuilder()
    kb.button(text="🚚 Отправлен (ввести трек)", callback_data=f"ship:{o['id']}")
    kb.button(text="✅ Доставлен", callback_data=f"deliv:{o['id']}")
    kb.adjust(1)
    return "\n".join(lines), kb.as_markup()


async def send_ship_queue(c: CallbackQuery, rows):
    for o in [r for r in rows if r["status"] == "paid" and (r["ship_status"] or "new") != "delivered"][:8]:
        text, kb = admin_order_card(o)
        await c.message.answer(chrome_text(text), reply_markup=kb)


class DeliveryForm(StatesGroup):
    name = State()
    phone = State()
    address = State()


class ShipForm(StatesGroup):
    track = State()


def cancel_kb(uid: int):
    return InlineKeyboardBuilder().button(text=DT[get_lang(uid)]["btn_cancel"], callback_data="dlx").as_markup()


@dp.callback_query(F.data.startswith("dl:"))
async def delivery_start(c: CallbackQuery, state: FSMContext):
    oid = int(c.data.split(":")[1])
    uid, lang = c.from_user.id, get_lang(c.from_user.id)
    o = own_order(c, oid)
    if not o or o["status"] != "paid":
        return await c.answer()
    await state.clear()
    kb = InlineKeyboardBuilder()
    for key in DELIVERY:
        kb.button(text=dname(lang, key), callback_data=f"dm:{oid}:{key}")
    kb.button(text=DT[lang]["btn_cancel"], callback_data="dlx")
    kb.adjust(2, 2, 1)
    await c.message.answer(dtr(uid, "ask_method", id=oid), reply_markup=kb.as_markup())
    await c.answer()


@dp.callback_query(F.data == "dlx")
async def delivery_cancel(c: CallbackQuery, state: FSMContext):
    await state.clear()
    await c.message.answer(dtr(c.from_user.id, "cancelled"))
    await c.answer()


@dp.callback_query(F.data.startswith("dm:"))
async def delivery_method(c: CallbackQuery, state: FSMContext):
    _, oid, key = c.data.split(":")
    o = own_order(c, int(oid))
    if not o or o["status"] != "paid" or key not in DELIVERY:
        return await c.answer()
    await state.set_state(DeliveryForm.name)
    await state.update_data(oid=int(oid), method=key)
    await c.message.answer(dtr(c.from_user.id, "ask_name"), reply_markup=cancel_kb(c.from_user.id))
    await c.answer()


@dp.message(StateFilter(DeliveryForm.name), F.text, ~F.text.startswith("/"))
async def delivery_name(m: Message, state: FSMContext):
    await state.update_data(name=m.text.strip()[:80])
    await state.set_state(DeliveryForm.phone)
    await m.answer(dtr(m.from_user.id, "ask_phone"), reply_markup=cancel_kb(m.from_user.id))


@dp.message(StateFilter(DeliveryForm.phone), F.text, ~F.text.startswith("/"))
async def delivery_phone(m: Message, state: FSMContext):
    digits = "".join(ch for ch in m.text if ch.isdigit())
    if not 7 <= len(digits) <= 15:
        return await m.answer(dtr(m.from_user.id, "bad_phone"))
    data = await state.update_data(phone=m.text.strip()[:30])
    if DELIVERY[data["method"]][2]:
        await state.set_state(DeliveryForm.address)
        return await m.answer(dtr(m.from_user.id, "ask_addr"), reply_markup=cancel_kb(m.from_user.id))
    await save_delivery(m, state, "")


@dp.message(StateFilter(DeliveryForm.address), F.text, ~F.text.startswith("/"))
async def delivery_address(m: Message, state: FSMContext):
    await save_delivery(m, state, m.text.strip()[:300])


async def save_delivery(m: Message, state: FSMContext, address: str):
    d = await state.get_data()
    await state.clear()
    uid, oid = m.from_user.id, d["oid"]
    with db() as con:
        cur = con.execute("UPDATE orders SET delivery_method=?, delivery_name=?, delivery_phone=?, delivery_address=?, "
                          "ship_status='new' WHERE id=? AND user_id=? AND status='paid'",
                          (d["method"], d["name"], d["phone"], address, oid, uid))
    if not cur.rowcount:
        return
    key = "saved" if DELIVERY[d["method"]][2] else "saved_pickup"
    await m.answer(dtr(uid, key, id=oid, method=dname(get_lang(uid), d["method"])))
    text, kb = admin_order_card(get_order(oid))
    await notify_admins(chrome_text("🔔 <b>Новые данные доставки</b>\n\n" + text), kb)


@dp.callback_query(F.data.startswith("ship:"))
async def ship_start(c: CallbackQuery, state: FSMContext):
    if c.from_user.id not in ADMIN_IDS:
        return await c.answer()
    oid = int(c.data.split(":")[1])
    await state.set_state(ShipForm.track)
    await state.update_data(oid=oid)
    await c.message.answer(f"Отправь трек-номер для заказа №{oid} (или «-», если трека нет):")
    await c.answer()


@dp.message(StateFilter(ShipForm.track), F.text, ~F.text.startswith("/"))
async def ship_track(m: Message, state: FSMContext):
    if not is_admin(m):
        return
    oid = (await state.get_data())["oid"]
    await state.clear()
    track = "" if m.text.strip() == "-" else m.text.strip()[:100]
    with db() as con:
        con.execute("UPDATE orders SET tracking=?, ship_status='shipped' WHERE id=?", (track, oid))
    o = get_order(oid)
    if not o:
        return
    cl = o["user_id"]
    track_html = f"<code>{esc(track)}</code>" if track else DT[get_lang(cl)]["no_track"]
    await bot.send_message(cl, dtr(cl, "shipped", id=oid, method=dname(get_lang(cl), o["delivery_method"]), track=track_html))
    await m.answer(f"🚚 Заказ №{oid} отмечен как отправленный, клиент уведомлён.")


@dp.callback_query(F.data.startswith("deliv:"))
async def mark_delivered(c: CallbackQuery):
    if c.from_user.id not in ADMIN_IDS:
        return await c.answer()
    oid = int(c.data.split(":")[1])
    with db() as con:
        con.execute("UPDATE orders SET ship_status='delivered' WHERE id=?", (oid,))
    o = get_order(oid)
    if o:
        await bot.send_message(o["user_id"], dtr(o["user_id"], "delivered", id=oid, store=esc(STORE_NAME)))
    await c.answer("Готово ✅", show_alert=True)


# ========================= поиск и фильтры в чате =========================
UF: dict = {}  # фильтры пользователей в чате (сбрасываются при перезапуске бота)
PRICE_BUCKETS = [(0, 5000), (5000, 10000), (10000, 20000), (20000, None)]


class SearchForm(StatesGroup):
    q = State()


def price_label(pr) -> str:
    lo, hi = pr
    if hi is None:
        return f"≥ {money(lo)}"
    if not lo:
        return f"≤ {money(hi)}"
    return f"{int(lo):,}".replace(",", " ") + f"–{money(hi)}"


def apply_filters(items, uid: int):
    f = UF.get(uid) or {}
    words = (f.get("q") or "").lower().split()
    lo, hi = f.get("price") or (None, None)
    out = []
    for p in items:
        hay = " ".join(str(p[k] or "") for k in ("brand", "title", "description")).lower()
        if f.get("size") and str(p["size"]).strip().lower() != f["size"].lower():
            continue
        if f.get("brand") and str(p["brand"]).strip().lower() != f["brand"].lower():
            continue
        if lo is not None and p["price"] < lo:
            continue
        if hi is not None and p["price"] >= hi:
            continue
        if words and not all(w in hay for w in words):
            continue
        out.append(p)
    return out


def filters_text(uid: int) -> str:
    f, d, parts = UF.get(uid) or {}, DT[get_lang(uid)], []
    if f.get("q"):
        parts.append(f"«{f['q']}»")
    if f.get("size"):
        parts.append(f"{d['size']} {f['size']}")
    if f.get("brand"):
        parts.append(f"{d['brand']} {f['brand']}")
    if f.get("price"):
        parts.append(price_label(f["price"]))
    return " · ".join(parts)


def filters_note(uid: int) -> str:
    text = filters_text(uid)
    return chrome_text(f"\n\n🔍 <i>{esc(text)}</i>") if text else ""


def filter_values(kind: str) -> list:
    vals = {str(p[kind]).strip() for p in available() if str(p[kind]).strip()}
    if kind == "size":
        return sorted(vals, key=lambda v: (not v.isdigit(), int(v) if v.isdigit() else 0, len(v), v))
    return sorted(vals, key=str.lower)


async def show_panel(c: CallbackQuery, text: str, kb):
    try:
        await c.message.edit_text(text, reply_markup=kb)
    except Exception:
        await c.message.answer(text, reply_markup=kb)
        try:
            await c.message.delete()
        except Exception:
            pass


def menu_panel(uid: int):
    lang = get_lang(uid)
    d = DT[lang]
    active = filters_text(uid)
    n = len(apply_filters(available(), uid))
    text = chrome_text(d["panel"].format(active=d["active"].format(text=esc(active)) if active else d["none_active"]))
    kb = InlineKeyboardBuilder()
    kb.button(text=d["size"], callback_data="f:size")
    kb.button(text=d["brand"], callback_data="f:brand")
    kb.button(text=d["price"], callback_data="f:price")
    kb.button(text=d["query"], callback_data="f:q")
    b(kb, d["show"].format(n=n), "success", callback_data="c:all:0")
    kb.button(text=d["reset"], callback_data="f:reset")
    kb.button(text=TXT[lang]["back"], callback_data="cats")
    kb.adjust(2, 2, 1, 2)
    return text, kb.as_markup()


@dp.callback_query(F.data.startswith("f:"))
async def filters_cb(c: CallbackQuery, state: FSMContext):
    uid = c.from_user.id
    d = DT[get_lang(uid)]
    action = c.data.split(":")[1]
    if action == "reset":
        UF.pop(uid, None)
        action = "menu"
    if action == "menu":
        await state.clear()
        text, kb = menu_panel(uid)
        await show_panel(c, text, kb)
    elif action in ("size", "brand"):
        kb = InlineKeyboardBuilder()
        for i, v in enumerate(filter_values(action)):
            kb.button(text=v, callback_data=f"fs:{action}:{i}")
        kb.button(text=d["any"], callback_data=f"fs:{action}:x")
        kb.adjust(3)
        await show_panel(c, d["pick_" + action], kb.as_markup())
    elif action == "price":
        kb = InlineKeyboardBuilder()
        for i, pr in enumerate(PRICE_BUCKETS):
            kb.button(text=price_label(pr), callback_data=f"fp:{i}")
        kb.button(text=d["any"], callback_data="fp:x")
        kb.adjust(2)
        await show_panel(c, d["pick_price"], kb.as_markup())
    elif action == "q":
        await state.set_state(SearchForm.q)
        await show_panel(c, d["ask_q"], None)
    await c.answer()


@dp.callback_query(F.data.startswith("fs:"))
async def filters_set(c: CallbackQuery):
    _, kind, i = c.data.split(":")
    uid = c.from_user.id
    vals = filter_values(kind) if kind in ("size", "brand") else []
    f = UF.setdefault(uid, {})
    if i == "x":
        f.pop(kind, None)
    elif i.isdigit() and int(i) < len(vals):
        f[kind] = vals[int(i)]
    text, kb = menu_panel(uid)
    await show_panel(c, text, kb)
    await c.answer()


@dp.callback_query(F.data.startswith("fp:"))
async def filters_price(c: CallbackQuery):
    i, uid = c.data.split(":")[1], c.from_user.id
    f = UF.setdefault(uid, {})
    if i == "x":
        f.pop("price", None)
    elif i.isdigit() and int(i) < len(PRICE_BUCKETS):
        f["price"] = PRICE_BUCKETS[int(i)]
    text, kb = menu_panel(uid)
    await show_panel(c, text, kb)
    await c.answer()


async def run_search(m: Message, q: str):
    uid = m.from_user.id
    UF.setdefault(uid, {})["q"] = q
    d = DT[get_lang(uid)]
    n = len(apply_filters(available(), uid))
    kb = InlineKeyboardBuilder()
    if n:
        b(kb, d["show"].format(n=n), "success", callback_data="c:all:0")
    kb.button(text=d["menu"], callback_data="f:menu")
    kb.adjust(1)
    await m.answer(d["found"].format(n=n) if n else d["nothing"], reply_markup=kb.as_markup())


@dp.message(StateFilter(SearchForm.q), F.text, ~F.text.startswith("/"))
async def search_text(m: Message, state: FSMContext):
    await state.clear()
    await run_search(m, m.text.strip()[:60])


@dp.message(Command("search"))
async def cmd_search(m: Message, command: CommandObject, state: FSMContext):
    ensure_user(m.from_user)
    if (command.args or "").strip():
        return await run_search(m, command.args.strip()[:60])
    await state.set_state(SearchForm.q)
    await m.answer(DT[get_lang(m.from_user.id)]["ask_q"])




@dp.message(F.func(lambda m: m.from_user.id in ADMIN_IDS
                   and any(e.type == "custom_emoji" for e in (m.entities or []))))
async def show_emoji_ids(m: Message):
    ids = [e.custom_emoji_id for e in m.entities if e.type == "custom_emoji"]
    await m.answer("ID эмодзи (нажми на ID, чтобы скопировать):\n" + "\n".join(f"<code>{i}</code>" for i in ids))


async def main():
    global BOT_USERNAME
    init_db()
    BOT_USERNAME = (await bot.get_me()).username
    await run_web()
    await bot.set_my_commands([BotCommand(command="start", description="Меню / Menu"),
                               BotCommand(command="catalog", description="Каталог / Catalog"),
                               BotCommand(command="orders", description="Мои заказы / My orders"),
                               BotCommand(command="search", description="Поиск / Search"),
                               BotCommand(command="lang", description="Язык / Language"),
                               BotCommand(command="admin", description="Панель администратора")])
    if WEBAPP_URL:
        await bot.set_chat_menu_button(menu_button=MenuButtonWebApp(text="Каталог", web_app=WebAppInfo(url=WEBAPP_URL)))
    asyncio.create_task(watcher())
    await dp.start_polling(bot)


if __name__ == "__main__":
    asyncio.run(main())
